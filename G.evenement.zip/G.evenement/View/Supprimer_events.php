<?php

    include_once 'C:/xampp/htdocs/G.evenement/Controller/eventsC.php';
	$eventsC = new eventsC();
    $eventsC->supprimerevents($_GET["id_ev"]);
	header('Location:gestion_events1.php');
?>





