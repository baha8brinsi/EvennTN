<?php

    include_once 'C:/xampp/htdocs/G.evenement/Controller/categoryC.php';
	$categoryC = new categoryC();
    $categoryC->supprimercategory($_GET["id"]);
	header('Location:gestion_category.php');
?>